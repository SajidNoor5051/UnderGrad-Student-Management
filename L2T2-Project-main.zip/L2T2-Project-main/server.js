const oracledb = require('oracledb');
//const axios= require('axios');
const express = require('express')
const path = require('path')
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT
const app = express();
app.set('view engine', 'ejs');
let id = '0'

//app.use(express.static('LoginPage'));
//app.use(express.static(path.join(__dirname, 'LoginPage')));
//app.use(express.static(path.join(__dirname,'Demo_Dashboard')));
//app.use(express.static('LoginPage'));
//app.use(express.static('Demo_Dashboard'));
app.use('/views', express.static(path.join(__dirname, 'views')));
app.use('/node_modules', express.static(path.join(__dirname, 'node_modules')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

//app.use('/LoginPage', express.static('views/LoginPage'));
//app.use('/Dashboard', express.static('views/Dashboard'));
app.listen(5000, () => { console.log('Listening on port 5000') });


async function run(query) {
  const connection = await oracledb.getConnection({
    user: 'C##BIISDEMO',
    password: 'biisdemo',  // contains the hr schema password
    connectString: "localhost/ORCL.Dlink"
  });

  const result = await connection.execute(query);
  await connection.close();
  return result;

  // Always close connections
}

app.get('/user/:id', async (req, res) => {
  console.log('connection complete');
  id = req.params.id;
  console.log(id);

  if (id[0] === 'S') {
    console.log(id[0]);
    const data = await run(`SELECT * FROM STUDENT WHERE STUDENT_ID LIKE '${id}'`);
    res.render('Dashboard/dashboard', { student_data: data.rows[0] });
  }
  else if (id[0] === 'A') {
    console.log(id[0]);
    const data = await run(`SELECT * FROM ADMIN WHERE ID LIKE '${id}'`);
    res.render('Admin_Dashboard/adminDashboard', { admin_data: data.rows[0] });
  }
})


app.get('/profile', async (req, res) => {
  console.log('connection complete');
  // const id = req.params.id;
  console.log(id);

  const data = await run(`SELECT * FROM STUDENT WHERE STUDENT_ID LIKE '${id}'`);
  console.log("Inside dashboard view INFO")
  res.render('ViewInfo/profile', { student_data: data.rows[0] });
})

app.get('/viewinfo', async (req, res) => {
  console.log('connection complete');
  // const id = req.params.id;
  console.log(id);

  const data = await run(`SELECT * FROM STUDENT WHERE STUDENT_ID LIKE '${id}'`);
  console.log("Inside dashboard view INFO");
  res.render('ViewInfo/fullinfo', { student_data: data.rows[0] });
})

app.get('/advisorInfo', async (req, res) => {
  console.log("Inside dashboard view Advisor INFO");
  console.log('connection complete');
  console.log(id);

  const data = await run(`SELECT * FROM teacher WHERE TEACHER_ID = (SELECT advisor_id FROM STUDENT WHERE Student_id LIKE  '${id}')`);
  res.render('ViewInfo/advisorinfo', { advisor_data: data.rows[0] });
})

app.get('/result', async (req, res) => {
  console.log(id);
  const level_term = await run(`SELECT LEVEL_TERM FROM STUDENT WHERE STUDENT_ID LIKE '${id}'`);

  //const course_data = await run(`SELECT * from ADVISOR WHERE ID =(SELECT STUDENT_ID LIKE '${id}'`);
  res.render('ViewResult/viewresult', { LT_data: level_term.rows[0] });
})

app.get('/notice', async (req, res) => {
  console.log('ntc2');
  //const level_term = await run(`SELECT LEVEL_TERM FROM STUDENT WHERE STUDENT_ID LIKE '${id}'`);

  //const course_data = await run(`SELECT * from ADVISOR WHERE ID =(SELECT STUDENT_ID LIKE '${id}'`);
  res.render('Notice/notice');
})


app.get('/changePass', async (req, res) => {
  console.log('Pass change');

  res.render('passwordChange/changepass');
})

app.get('/studentViewCourses/:status', async (req, res) => {
  if(req.params.status === "current"){

  }
  else if(req.params.status === "available"){
    
  }
  else if(req.params.status === "completed"){
    
  }
 
})

app.get('/admin/viewAllStudents',async (req,res) =>{
  const noOfData = await run(`SELECT count(*) count FROM student`);
  const depts = await run('SELECT Department FROM STUDENT  GROUP BY DEPARTMENT')
  const level_terms = await run('SELECT LEVEL_TERM  FROM STUDENT GROUP BY LEVEL_TERM ORDER BY LEVEL_TERM asc')
  console.log(depts);
  res.render('ViewAllStudents/AllStudentsCategory',{noOfData,depts,level_terms});

})
app.get('/admin/viewAllTeachers',async (req,res) =>{
  const noOfData = await run(`SELECT count(*) count FROM TEACHER`);
  const depts = await run('SELECT Department FROM TEACHER  GROUP BY DEPARTMENT')
  const designation = await run('SELECT DESIGNATION  FROM TEACHER  GROUP BY DESIGNATION ')
  console.log(depts);
  res.render('ViewAllTeachers/CriteriaWise',{noOfData,depts,designation});

})
app.get('/admin/viewAllCourses',async (req,res) =>{
  const noOfData = await run(`SELECT count(*) count FROM COURSES`);
  const depts = await run('SELECT Department,count(*) COUNT FROM COURSES  GROUP BY DEPARTMENT')
  const level_term = await run('SELECT LEVEL_TERM ,count(*) COUNT FROM COURSES GROUP BY LEVEL_TERM ORDER BY LEVEL_TERM ASC')
  console.log(depts);
  res.render('ViewAllCourses/CriteriaWiseCourses',{noOfData,depts,level_term});

})
app.get('/AllStudents/:str',async (req,res) =>{
  let str = req.params.str;
  let strActual = str.substring(0,str.length -1 )
  console.log(str);
  console.log(strActual);
  if(str === "viewAll"){
  const data = await run(`SELECT * from  STUDENT`);
  console.log("data fetched inside Allstudents");
  res.render('ViewAllStudents/allStudents',{data});
  }
  else if(str[str.length-1]==="D") {
    const data = await run(`SELECT *FROM STUDENT S WHERE DEPARTMENT Like '${strActual}'`);
    console.log("data fetched inside Depts");
    res.render('ViewAllStudents/allStudents',{data});
  }

  else if(str[str.length-1]==="L") {
    const data = await run(`SELECT *FROM STUDENT S WHERE LEVEL_TERM Like '${strActual}'`);
    console.log("data fetched inside Depts");
    res.render('ViewAllStudents/allStudents',{data});
  }


})


app.get('/AllTeachers/:str',async (req,res) =>{
  let str = req.params.str;
  let strActual = str.substring(0,str.length -1 )
  console.log(str);
  console.log(strActual);
  if(str === "viewAll"){
  const data = await run(`SELECT * from  TEACHER`);
  console.log("data fetched inside AllTeachers");
  res.render('ViewAllTeachers/allTeachers',{data});
  }
  else if(str[str.length-1]==="D"){
    const data = await run(`SELECT *FROM TEACHER WHERE DEPARTMENT Like '${strActual}'`);
    console.log("data fetched inside teacher wise dept");
    res.render('ViewAllTeachers/allTeachers',{data});

  }
  else if(str[str.length-1]==="d") {
    const data = await run(`SELECT *FROM TEACHER WHERE DESIGNATION Like '${strActual}'`);
    console.log("data fetched inside teacher wise desg");
    res.render('ViewAllTeachers/allTeachers',{data});
  }

})




app.get('/AllCourses/:str',async (req,res) =>{
  let str = req.params.str;
  let strActual = str.substring(0,str.length -1 )
  console.log(str);
  console.log(strActual);
  if(str=== "viewAll"){
  const data = await run(`SELECT * from  COURSES`);
  console.log("data fetched inside AllTeachers");
  res.render('ViewAllCourses/allCourses',{data});
  }
  else if(str[str.length-1]==="D"){
    const data = await run(`SELECT *FROM COURSES WHERE DEPARTMENT Like '${strActual}'`);
    console.log("data fetched inside courses wise dept");
    res.render('ViewAllCourses/allCourses',{data});

  }
  else if(str[str.length-1]==="L") {
    const data = await run(`SELECT * FROM COURSES WHERE LEVEL_TERM Like '${strActual}'`);
    console.log("data fetched inside courses wise Level term");
    res.render('ViewAllCourses/allCourses',{data});
  }

})


app.get('/', async (req, res) => {
  console.log("Hello ,You are connected ! ");
  res.render('LoginPage/index');

});