const informationDiv = document.getElementById("informationDiv");
const result = document.getElementById("result");
const viewInfo = document.getElementById("viewInfo");
const advisorInfo = document.getElementById("advisorInfo");
const notice = document.getElementById("notice");
const changePass = document.getElementById("changePass");
const Profile = document.getElementById("Profile");
const id_input = document.getElementById("idInput");
const dropdownText = document.getElementById('navbarDropdown');
const log_out = document.getElementById("logout");
const home = document.getElementById("home");
const currentCourse = document.getElementById("currentCourse");
const availableCourse = document.getElementById("availableCourse");
const completedCourse = document.getElementById("completedCourse");


log_out.addEventListener("click", function () {
  console.log("Logout Clicked");
  var result = confirm("Are you sure you want to log out?");
  if (result) {
    // Perform logout actions here
    alert("Logged out successfully");
    // You can redirect to a logout page or perform other actions
  }
});
result.addEventListener("click", async function () {
  //This will be request to server and response from server
  //code
  const response = await fetch(`/result`);
  const contents = await response.text();
  console.log(contents);
  informationDiv.innerHTML = contents;
});

viewInfo.addEventListener("click", async function () {
  //This will be request to server and response from server
  //code
  const response = await fetch(`/viewinfo`);
  const contents = await response.text();
  informationDiv.innerHTML = contents;
})
Profile.addEventListener("click", async function () {
  const response = await fetch(`/profile`);
  const contents = await response.text();
  console.log(contents);
  console.log(contents);
  informationDiv.innerHTML = contents;
})
changePass.addEventListener("click", async function () {
  //This will be request to server and response from server
  //code
  console.log("Change pass clicked");
  try {
    const response = await fetch(`/changePass`);
    const contents = await response.text(); // Await the response text
    informationDiv.innerHTML = contents;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
})

advisorInfo.addEventListener("click", async function () {
  //This will be request to server and response from server
  //code
  const response = await fetch(`/advisorInfo`);
  const contents = await response.text();
  console.log(contents);
  informationDiv.innerHTML = contents;
})
home.addEventListener("click", async function () {
  const response = await fetch(`/profile`);
  const contents = await response.text();
  console.log(contents);
  console.log(contents);
  informationDiv.innerHTML = contents;
})

notice.addEventListener("click", async function () {
  const response = await fetch(`/notice`);
  const contents = await response.text();
  console.log('ntc');
  console.log(contents);
  informationDiv.innerHTML = contents;
})

currentCourse.addEventListener("click",async function(){
  const response = await fetch(`/studentViewCourses/current`);
  const contents = await response.text();
  informationDiv.innerHTML = contents;
})

availableCourseCourse.addEventListener("click",async function(){
  const response = await fetch(`/studentViewCourses/available`);
  const contents = await response.text();
  informationDiv.innerHTML = contents;
})

completedCourse.addEventListener("click",async function(){
  const response = await fetch(`/studentViewCourses/completed`);
  const contents = await response.text();
  informationDiv.innerHTML = contents;
})

