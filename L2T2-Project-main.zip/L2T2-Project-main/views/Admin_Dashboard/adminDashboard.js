const viewAllStudents = document.getElementById("viewAllStudents");
const viewAllTeachers = document.getElementById("viewAllTeachers");
const viewAllCourses = document.getElementById("ViewAllCourses");
const informationDiv = document.getElementById("informationDiv")

viewAllStudents.addEventListener("click", async function () {
  //This will be request to server and response from server
  //code
  const response = await fetch('/admin/viewAllStudents');
  const contents = await response.text();
  console.log(contents);
  informationDiv.innerHTML = contents;
});

viewAllTeachers.addEventListener("click", async function () {
  //This will be request to server and response from server
  //code
  const response = await fetch('/admin/viewAllTeachers');
  const contents = await response.text();
  console.log(contents);
  informationDiv.innerHTML = contents;
});

viewAllCourses.addEventListener("click", async function () {
  //This will be request to server and response from server
  //code
  const response = await fetch('/admin/viewAllCourses');
  const contents = await response.text();
  console.log(contents);
  informationDiv.innerHTML = contents;
});



informationDiv.addEventListener("click", async function (event) {
  if (event.target && event.target.id === "allStudents") {
    // Handle the click event
    console.log("Clicked");
    const response = await fetch('/AllStudents/viewAll');
    const contents = await response.text();

    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }
  if (event.target && event.target.id === "allTeachers") {
    // Handle the click event
    console.log("Clicked");
    const response = await fetch('/AllTeachers/viewAll');
    const contents = await response.text();

    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }
  if (event.target && event.target.id === "allCourses") {
    // Handle the click event
    const response = await fetch('/AllCourses/viewAll');
    const contents = await response.text();

    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }
  if (event.target && event.target.classList.contains("Deptsharedanchor")) {
    // Get the text content of the clicked anchor
    let anchorText = event.target.textContent.trim();
    anchorText = anchorText + 'D';
    console.log(anchorText);
    const response = await fetch(`/AllStudents/${anchorText}`);
    const contents = await response.text();
    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }
  if (event.target && event.target.classList.contains("L_Tsharedanchor")) {
    // Get the text content of the clicked anchor
    let anchorText = event.target.textContent.trim();
    anchorText = anchorText + 'L';
    console.log(anchorText);
    const response = await fetch(`/AllStudents/${anchorText}`);
    const contents = await response.text();
    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }
  if (event.target && event.target.classList.contains("DeptWiseTeacherAnchor")) {
    // Get the text content of the clicked anchor
    let anchorText = event.target.textContent.trim();
    anchorText = anchorText + 'D';
    console.log(anchorText);
    const response = await fetch(`/AllTeachers/${anchorText}`);
    const contents = await response.text();
    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }
  if (event.target && event.target.classList.contains("DesignationWiseTeacherAnchor")) {
    // Get the text content of the clicked anchor
    let anchorText = event.target.textContent.trim();
    anchorText = anchorText + 'd';
    console.log(anchorText);
    const response = await fetch(`/AllTeachers/${anchorText}`);
    const contents = await response.text();
    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }

  if (event.target && event.target.classList.contains("DeptCoursesAnchor")) {
    // Get the text content of the clicked anchor
    let anchorText = event.target.textContent.trim();
    anchorText = anchorText + 'D';
    console.log(anchorText);
    const response = await fetch(`/AllCourses/${anchorText}`);
    const contents = await response.text();
    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }

  if (event.target && event.target.classList.contains("L_TCoursesAnchor")) {
    // Get the text content of the clicked anchor
    let anchorText = event.target.textContent.trim();
    anchorText = anchorText + 'L';
    console.log(anchorText);
    const response = await fetch(`/AllCourses/${anchorText}`);
    const contents = await response.text();
    const div2 = document.getElementById("div2");
    div2.innerHTML = contents;
  }
  
});